﻿
namespace Ploeh.Samples.MeffyXmas.MenuModel
{
    public sealed class OliveOil { }
}
