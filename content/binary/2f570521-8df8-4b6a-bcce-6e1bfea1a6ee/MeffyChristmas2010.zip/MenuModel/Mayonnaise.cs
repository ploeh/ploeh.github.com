﻿using System;

namespace Ploeh.Samples.MeffyXmas.MenuModel
{
    public sealed class Mayonnaise
    {
        private readonly EggYolk eggYolk;
        private readonly OliveOil oil;

        public Mayonnaise(EggYolk eggYolk, OliveOil oil)
        {
            if (eggYolk == null)
            {
                throw new ArgumentNullException("eggYolk");
            }
            if (oil == null)
            {
                throw new ArgumentNullException("oil");
            }

            this.eggYolk = eggYolk;
            this.oil = oil;
        }

        public EggYolk EggYolk
        {
            get { return this.eggYolk; }
        }

        public OliveOil Oil
        {
            get { return this.oil; }
        }
    }
}
