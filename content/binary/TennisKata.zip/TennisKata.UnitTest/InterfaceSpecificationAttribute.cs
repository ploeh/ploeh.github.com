﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit;

namespace Ploeh.Samples.TennisKata.UnitTest
{
    public class InterfaceSpecificationAttribute : RunWithAttribute
    {
        public InterfaceSpecificationAttribute()
            : base(typeof(InterfaceSpecificationClassCommand))
        {
        }
    }
}
