﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit.Extensions;
using Xunit;
using Moq;

namespace Ploeh.Samples.TennisKata.UnitTest
{
    public class AdvantagePointFacts
    {
        [Theory, AutoTennisData]
        public void SutIsPoints(AdvantagePoint sut)
        {
            Assert.IsAssignableFrom<IPoints>(sut);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstPointsThrows(AdvantagePoint sut, IPoints opponentPoints)
        {
            Assert.Throws<InvalidOperationException>(() => 
                sut.WinBall(opponentPoints));
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstFortyPointsReturnsCorrectResult(AdvantagePoint sut, FortyPoints opponentPoints)
        {
            IPoints result = sut.WinBall(opponentPoints);
            Assert.IsAssignableFrom<GamePoint>(result);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstAdvantagePointThrows(AdvantagePoint sut, AdvantagePoint opponentPoints)
        {
            Assert.Throws<InvalidOperationException>(() =>
                sut.WinBall(opponentPoints));
        }

        [Theory, AutoTennisData]
        public void LoseBallReturnsCorrectResult(AdvantagePoint sut)
        {
            IPoints result = sut.LoseBall();
            Assert.IsAssignableFrom<FortyPoints>(result);
        }

        [Theory, AutoTennisData]
        public void AcceptReturnsCorrectResult(AdvantagePoint sut, Mock<IPoints> visitorStub, IPoints expectedPoints)
        {
            visitorStub.Setup(v => v.WinBall(sut)).Returns(expectedPoints);
            IPoints result = sut.Accept(visitorStub.Object);
            Assert.Equal(expectedPoints, result);
        }

        [Theory, AutoTennisData]
        public void SutIsEqualToOtherSut(AdvantagePoint sut, AdvantagePoint other)
        {
            Assert.True(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void SutIsNotEqualToOtherScore(AdvantagePoint sut, IPoints other)
        {
            Assert.False(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void SutIsNotEqualToOtherObject(AdvantagePoint sut, object other)
        {
            Assert.False(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void GetHashCodeReturnsStableResult(AdvantagePoint sut)
        {
            Assert.Equal(41, sut.GetHashCode());
        }
    }
}
