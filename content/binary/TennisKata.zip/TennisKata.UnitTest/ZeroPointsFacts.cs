﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ploeh.AutoFixture.Xunit;
using Xunit.Extensions;
using Xunit;
using Ploeh.Samples.TennisKata;
using Moq;

namespace Ploeh.Samples.TennisKata.UnitTest
{
    public class ZeroPointsFacts
    {
        [Theory, AutoTennisData]
        public void SutIsScore(ZeroPoints sut)
        {
            Assert.IsAssignableFrom<IPoints>(sut);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstPointsReturnsCorrectResult(ZeroPoints sut, IPoints opponentPoints)
        {
            IPoints result = sut.WinBall(opponentPoints);
            Assert.IsAssignableFrom<FifteenPoints>(result);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstZeroScoreReturnsCorrectResult(ZeroPoints sut, ZeroPoints opponentPoints)
        {
            IPoints result = sut.WinBall(opponentPoints);
            Assert.IsAssignableFrom<FifteenPoints>(result);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstFifteenScoreReturnsCorrectResult(ZeroPoints sut, FifteenPoints opponentPoints)
        {
            IPoints result = sut.WinBall(opponentPoints);
            Assert.IsAssignableFrom<FifteenPoints>(result);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstThirtyScoreReturnsCorrectResult(ZeroPoints sut, ThirtyPoints opponentPoints)
        {
            IPoints result = sut.WinBall(opponentPoints);
            Assert.IsAssignableFrom<FifteenPoints>(result);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstFortyScoreReturnsCorrectResult(ZeroPoints sut, FortyPoints opponentPoints)
        {
            IPoints result = sut.WinBall(opponentPoints);
            Assert.IsAssignableFrom<FifteenPoints>(result);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstAdvantageThrows(ZeroPoints sut, AdvantagePoint opponentPoints)
        {
            Assert.Throws<InvalidOperationException>(() =>
                sut.WinBall(opponentPoints));
        }

        [Theory, AutoTennisData]
        public void LoseBallReturnsCorrectResult(ZeroPoints sut)
        {
            IPoints result = sut.LoseBall();
            Assert.IsAssignableFrom<ZeroPoints>(result);
        }

        [Theory, AutoTennisData]
        public void SutIsEqualToOtherSut(ZeroPoints sut, ZeroPoints other)
        {
            Assert.True(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void SutIsNotEqualToOtherScore(ZeroPoints sut, IPoints other)
        {
            Assert.False(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void SutIsNotEqualToOtherObject(ZeroPoints sut, object other)
        {
            Assert.False(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void GetHashCodeReturnsStableResult(ZeroPoints sut)
        {
            Assert.Equal(0, sut.GetHashCode());
        }
    }
}
