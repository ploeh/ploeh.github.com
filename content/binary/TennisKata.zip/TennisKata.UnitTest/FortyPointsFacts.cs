﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit.Extensions;
using Xunit;
using Ploeh.Samples.TennisKata;
using Moq;

namespace Ploeh.Samples.TennisKata.UnitTest
{
    public class FortyPointsFacts
    {
        [Theory, AutoTennisData]
        public void SutIsPoints(FortyPoints sut)
        {
            Assert.IsAssignableFrom<IPoints>(sut);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstPointsReturnsCorrectResult(FortyPoints sut, IPoints opponentPoints)
        {
            IPoints result = sut.WinBall(opponentPoints);
            Assert.IsAssignableFrom<GamePoint>(result);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstFortyPointsReturnsCorrectResult(FortyPoints sut, FortyPoints opponentPoints)
        {
            IPoints result = sut.WinBall(opponentPoints);
            Assert.IsAssignableFrom<AdvantagePoint>(result);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstAdvantagePointReturnsCorrectResult(FortyPoints sut, AdvantagePoint opponentPoints)
        {
            var result = sut.WinBall(opponentPoints);
            Assert.IsAssignableFrom<FortyPoints>(result);
        }

        [Theory, AutoTennisData]
        public void LoseBallReturnsCorrectResult(FortyPoints sut)
        {
            IPoints result = sut.LoseBall();
            Assert.IsAssignableFrom<FortyPoints>(result);
        }

        [Theory, AutoTennisData]
        public void AcceptReturnsCorrectResult(FortyPoints sut, Mock<IPoints> visitorStub, IPoints expectedPoints)
        {
            visitorStub.Setup(v => v.WinBall(sut)).Returns(expectedPoints);
            IPoints result = sut.Accept(visitorStub.Object);
            Assert.Equal(expectedPoints, result);
        }

        [Theory, AutoTennisData]
        public void SutIsEqualToOtherSut(FortyPoints sut, FortyPoints other)
        {
            Assert.True(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void SutIsNotEqualToOtherScore(FortyPoints sut, IPoints other)
        {
            Assert.False(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void SutIsNotEqualToOtherObject(FortyPoints sut, object other)
        {
            Assert.False(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void GetHashCodeReturnsStableResult(FortyPoints sut)
        {
            Assert.Equal(40, sut.GetHashCode());
        }
    }
}
