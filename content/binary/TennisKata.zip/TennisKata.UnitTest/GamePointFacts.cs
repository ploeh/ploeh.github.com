﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit.Extensions;
using Xunit;

namespace Ploeh.Samples.TennisKata.UnitTest
{
    public class GamePointFacts
    {
        [Theory, AutoTennisData]
        public void SutIsPoints(GamePoint sut)
        {
            Assert.IsAssignableFrom<IPoints>(sut);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstPointsThrows(GamePoint sut, IPoints opponentPoints)
        {
            Assert.Throws<InvalidOperationException>(() =>
                sut.WinBall(opponentPoints));
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstFortyPointsThrows(GamePoint sut, FortyPoints opponentPoints)
        {
            Assert.Throws<InvalidOperationException>(() =>
                sut.WinBall(opponentPoints));
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstAdvantagePointThrows(GamePoint sut, AdvantagePoint opponentPoints)
        {
            Assert.Throws<InvalidOperationException>(() =>
                sut.WinBall(opponentPoints));
        }

        [Theory, AutoTennisData]
        public void LoseBallThrows(GamePoint sut)
        {
            Assert.Throws<InvalidOperationException>(() =>
                sut.LoseBall());
        }

        [Theory, AutoTennisData]
        public void AcceptThrows(GamePoint sut, IPoints visitor)
        {
            Assert.Throws<InvalidOperationException>(() =>
                sut.Accept(visitor));
        }

        [Theory, AutoTennisData]
        public void SutIsEqualToOtherSut(GamePoint sut, GamePoint other)
        {
            Assert.True(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void SutIsNotEqualToOtherScore(GamePoint sut, IPoints other)
        {
            Assert.False(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void SutIsNotEqualToOtherObject(GamePoint sut, object other)
        {
            Assert.False(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void GetHashCodeReturnsStableResult(GamePoint sut)
        {
            Assert.Equal(42, sut.GetHashCode());
        }
    }
}
