﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit.Extensions;
using Moq;
using Xunit;

namespace Ploeh.Samples.TennisKata.UnitTest
{
    [InterfaceSpecification]
    public class PointsSpecification<T> where T : IPoints
    {
        [Theory, AutoTennisData]
        public void AcceptReturnsCorrectResult(T sut, Mock<IPoints> visitorStub, IPoints expectedPoints)
        {
            visitorStub.Setup(v => v.WinBall(sut)).Returns(expectedPoints);
            IPoints result = sut.Accept(visitorStub.Object);
            Assert.Equal(expectedPoints, result);
        }
    }
}
