﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit.Sdk;
using System.Reflection;

namespace Ploeh.Samples.TennisKata.UnitTest
{
    public class InterfaceSpecificationClassCommand : ITestClassCommand
    {
        private readonly ITestClassCommand cmd;

        public InterfaceSpecificationClassCommand()
        {
            this.cmd = new TestClassCommand();
        }

        #region ITestClassCommand Members

        public int ChooseNextTest(ICollection<IMethodInfo> testsLeftToRun)
        {
            return this.cmd.ChooseNextTest(testsLeftToRun);
        }

        public Exception ClassFinish()
        {
            return this.cmd.ClassFinish();
        }

        public Exception ClassStart()
        {
            return this.cmd.ClassStart();
        }

        public IEnumerable<ITestCommand> EnumerateTestCommands(IMethodInfo testMethod)
        {
            return this.cmd.EnumerateTestCommands(testMethod);
        }

        // Warning: prototype code only
        public IEnumerable<IMethodInfo> EnumerateTestMethods()
        {
            foreach (var m in this.cmd.EnumerateTestMethods())
            {
                var genericOwner = m.MethodInfo.DeclaringType;
                var implementers = new[] { typeof(ZeroPoints), typeof(FifteenPoints), typeof(ThirtyPoints) };
                foreach (var t in implementers)
                {
                    var constructedOwner = genericOwner.MakeGenericType(t);
                    var constructedMethod = (MethodInfo)MethodBase.GetMethodFromHandle(m.MethodInfo.MethodHandle, constructedOwner.TypeHandle);
                    yield return Reflector.Wrap(constructedMethod);
                }
            }
        }

        public bool IsTestMethod(IMethodInfo testMethod)
        {
            return this.IsTestMethod(testMethod);
        }

        public object ObjectUnderTest
        {
            get { return this.cmd.ObjectUnderTest; }
        }

        public ITypeInfo TypeUnderTest
        {
            get
            {
                return this.cmd.TypeUnderTest;
            }
            set
            {
                this.cmd.TypeUnderTest = value;
            }
        }

        #endregion
    }
}
