﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit.Extensions;
using Xunit;
using Moq;

namespace Ploeh.Samples.TennisKata.UnitTest
{
    public class FifteenPointsFacts
    {
        [Theory, AutoTennisData]
        public void SutIsPoints(FifteenPoints sut)
        {
            Assert.IsAssignableFrom<IPoints>(sut);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstPointsReturnsCorrectResult(FifteenPoints sut, IPoints opponentPoints)
        {
            IPoints result = sut.WinBall(opponentPoints);
            Assert.IsAssignableFrom<ThirtyPoints>(result);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstFortyPointsReturnsCorrectResult(FifteenPoints sut, FortyPoints opponentPoints)
        {
            IPoints result = sut.WinBall(opponentPoints);
            Assert.IsAssignableFrom<ThirtyPoints>(result);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstAdvantagePointThrows(FifteenPoints sut, AdvantagePoint opponentPoints)
        {
            Assert.Throws<InvalidOperationException>(() =>
                sut.WinBall(opponentPoints));
        }

        [Theory, AutoTennisData]
        public void LoseBallReturnsCorrectResult(FifteenPoints sut)
        {
            IPoints result = sut.LoseBall();
            Assert.IsAssignableFrom<FifteenPoints>(result);
        }

        [Theory, AutoTennisData]
        public void SutIsEqualToOtherSut(FifteenPoints sut, FifteenPoints other)
        {
            Assert.True(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void SutIsNotEqualToOtherScore(FifteenPoints sut, IPoints other)
        {
            Assert.False(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void SutIsNotEqualToOtherObject(FifteenPoints sut, object other)
        {
            Assert.False(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void GetHashCodeReturnsStableResult(FifteenPoints sut)
        {
            Assert.Equal(15, sut.GetHashCode());
        }
    }
}
