﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit.Extensions;
using Xunit;
using Moq;

namespace Ploeh.Samples.TennisKata.UnitTest
{
    public class ThirtyPointsFacts
    {
        [Theory, AutoTennisData]
        public void SutIsPoints(ThirtyPoints sut)
        {
            Assert.IsAssignableFrom<IPoints>(sut);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstPointsReturnsCorrectResult(ThirtyPoints sut, IPoints opponentPoints)
        {
            IPoints result = sut.WinBall(opponentPoints);
            Assert.IsAssignableFrom<FortyPoints>(result);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstFortyPointsReturnsCorrectResult(ThirtyPoints sut, FortyPoints opponentPoints)
        {
            IPoints result = sut.WinBall(opponentPoints);
            Assert.IsAssignableFrom<FortyPoints>(result);
        }

        [Theory, AutoTennisData]
        public void WinBallAgainstAdvantagePointThrows(ThirtyPoints sut, AdvantagePoint opponentPoints)
        {
            Assert.Throws<InvalidOperationException>(() =>
                sut.WinBall(opponentPoints));
        }

        [Theory, AutoTennisData]
        public void LoseBallReturnsCorrectResult(ThirtyPoints sut)
        {
            IPoints result = sut.LoseBall();
            Assert.IsAssignableFrom<ThirtyPoints>(result);
        }

        [Theory, AutoTennisData]
        public void SutIsEqualToOtherSut(ThirtyPoints sut, ThirtyPoints other)
        {
            Assert.True(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void SutIsNotEqualToOtherScore(ThirtyPoints sut, IPoints other)
        {
            Assert.False(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void SutIsNotEqualToOtherObject(ThirtyPoints sut, object other)
        {
            Assert.False(sut.Equals(other));
        }

        [Theory, AutoTennisData]
        public void GetHashCodeReturnsStableResult(ThirtyPoints sut)
        {
            Assert.Equal(30, sut.GetHashCode());
        }
    }
}
