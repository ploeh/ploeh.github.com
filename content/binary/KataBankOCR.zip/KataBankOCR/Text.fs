﻿module Text

open System

let ToString chars = String(chars |> Seq.toArray)