﻿module CombinatoricsTests

open Text
open Sequences
open FsUnit.Xunit
open Xunit
open Xunit.Extensions
open TestInfrastructure

[<Theory>]
[<InlineData("123", 0, '7', "723")>]
[<InlineData("123", 1, '7', "173")>]
[<InlineData("123", 2, '7', "127")>]
[<InlineData("1234", 0, '3', "3234")>]
let ReplaceElementReturnsCorrectResult sequence index element (expected : string) =
    sequence
    |> ReplaceElementAt index element
    |> should equalSequence expected

[<Fact>]
let ProduceAllReplacementsAtReturnsCorrectResult1() =
    let actual = ReplaceAt 0 (fun c -> [ 'I'; 'i' ]) "123"
    actual |> Seq.map ToString |> should equalSequence [ "I23"; "i23" ]

[<Fact>]
let ProduceAllReplacementsAtReturnsCorrectResult2() =
    let actual = ReplaceAt 1 (fun c -> [ 'V' ]) "153"
    actual |> Seq.map ToString |> should equalSequence [ "1V3" ]