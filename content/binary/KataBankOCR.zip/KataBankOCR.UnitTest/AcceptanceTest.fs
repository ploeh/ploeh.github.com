﻿module AcceptanceTest

open System.IO
open FsUnit.Xunit
open Xunit
open OCR

[<Fact>]
let TheFinalTest() =
    let input = File.ReadAllText "Input.txt"

    let entries = input |> SplitEntries |> Seq.toArray
    let actual = entries |> Seq.map ParseToPrintout |> Seq.reduce (fun x y -> sprintf "%s\r\n%s" x y)

    let expected = File.ReadAllText "ExpectedOutput.txt"
    actual |> should equal expected