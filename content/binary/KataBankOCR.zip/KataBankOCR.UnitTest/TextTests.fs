﻿module TextTests

open Text
open Xunit
open Xunit.Extensions
open FsUnit.Xunit

[<Theory>]
[<InlineData('1', '2', '3', "123")>]
[<InlineData('1', '1', '1', "111")>]
let ToStringReturnsCorrectResult c1 c2 c3 expected =
    [| c1; c2; c3 |]
    |> ToString
    |> should equal expected