﻿module TestInfrastructure

open System.Linq
open NHamcrest

let equalSequence (s : 'a seq) =
    let isMatch (actual : obj) =
        match actual with
        | :? seq<'a> as actualSeq -> Enumerable.SequenceEqual(s, actualSeq)
        | _ -> false

    CustomMatcher<obj>(s.ToString(), fun actual -> isMatch actual)